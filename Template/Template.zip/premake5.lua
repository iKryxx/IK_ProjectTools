-- premake4.lua
workspace "workshop"
    architecture "x64"
    configurations
    {
        "Debug",
        "Release"
    }

outputDir = "%{cfg.buildcfg}-%{cfg.system}-%{cfg.architecture}"

project "qwj1kwL5CPvBeVEzlVoQqRUnJyPAcDLP"
    kind "ConsoleApp"
    language "C++"
    cppdialect "C++20"
    targetdir ("bin/" .. outputDir)
    objdir ("build/" .. outputDir)
    debugdir ("bin/" .. outputDir)
    
    libdirs { "libs" }
    flags { "MultiProcessorCompile" }

    files
    {
        "%{prj.name}/inc/**.h",
        "utils/src/**.cpp",
        "%{prj.name}/src/**.cpp"

    }
    includedirs
    {
        "utils/inc/",
        "%{prj.name}/inc/"
    }

    filter "system:Windows"
        systemversion "latest"
        staticruntime "On"
        defines
        { }
    filter "system:Linux"
        systemversion "latest"
        staticruntime "On"
        defines
        { }

    filter "configurations:Debug"
        runtime "Debug"
        symbols "On"
        --warnings "Everything"
        defines
        {
            "IK_DEFINE_DEBUG"
        }
    filter "configurations:Release" 
        runtime "Release"
        optimize "On"
        --warnings "Default"
        defines
        {
            "IK_DEFINE_RELEASE"
        }
