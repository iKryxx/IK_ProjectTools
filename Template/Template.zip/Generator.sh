sudo ./premake5/premake5 gmake
